sudo apt-get update
sudo apt-get install nodejs npm -y
node -e "console.log('Running Node.js ' + process.version)"
sudo rm -rf ~/App