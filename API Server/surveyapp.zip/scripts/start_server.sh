forever stopall
forever start ~/App/index.js