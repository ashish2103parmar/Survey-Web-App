sudo npm install forever -g
sudo chown -R ubuntu:ubuntu ~/App
cd ~/App
npm install