/**
 * Resource Names and Credentials
 */

// Directory DB
exports.surveyDB = {
    name: "survey-db",
    key: "pkey",
};